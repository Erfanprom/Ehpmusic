package com.ehprogramer.musicpro

import android.Manifest
import android.app.Application
import android.content.ContentUris
import android.content.Context
import android.media.audiofx.Equalizer
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.MediaStore
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.*
import androidx.compose.foundation.lazy.grid.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.media3.common.AudioAttributes
import androidx.media3.common.C
import androidx.media3.common.MediaItem
import androidx.media3.common.Player
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.ui.PlayerView
import coil.compose.AsyncImage
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.net.URL
import java.net.URLEncoder

val G = Color(0xFF22C55E)
val BG = Color(0xFF121212)

data class Track(val id: String, val title: String, val artist: String, val art: String?, val url: String, val video: Boolean = false)

class VM(app: Application) : AndroidViewModel(app) {
    val p = ExoPlayer.Builder(app).build()
    private val sp = app.getSharedPreferences("eh", Context.MODE_PRIVATE)
    var local by mutableStateOf(listOf<Track>())
    var results by mutableStateOf(listOf<Track>())
    var fav by mutableStateOf(load("fav"))
    var off by mutableStateOf(load("off"))
    var cur by mutableStateOf<Track?>(null)
    var playing by mutableStateOf(false)
    var lyrics by mutableStateOf<String?>(null)
    var busy by mutableStateOf(false)
    private var eq: Equalizer? = null

    init {
        p.setAudioAttributes(AudioAttributes.Builder().setUsage(C.USAGE_MEDIA).setContentType(C.AUDIO_CONTENT_TYPE_MUSIC).build(), true)
        p.addListener(object : Player.Listener { override fun onIsPlayingChanged(isPlaying: Boolean) { playing = isPlaying } })
    }

    private fun enc(s: String) = URLEncoder.encode(s, "UTF-8")
    private fun file(t: Track) = File(getApplication<Application>().filesDir, t.id + ".dl")

    private fun load(k: String): List<Track> = runCatching {
        val a = JSONArray(sp.getString(k, "[]"))
        (0 until a.length()).map {
            val o = a.getJSONObject(it)
            Track(o.getString("id"), o.getString("t"), o.getString("a"), o.optString("i").ifEmpty { null }, o.getString("u"), o.optBoolean("v"))
        }
    }.getOrDefault(emptyList())

    private fun save(k: String, l: List<Track>) = sp.edit().putString(k, JSONArray(l.map {
        JSONObject().put("id", it.id).put("t", it.title).put("a", it.artist).put("i", it.art ?: "").put("u", it.url).put("v", it.video)
    }).toString()).apply()

    fun scanLocal() = viewModelScope.launch(Dispatchers.IO) {
        val out = mutableListOf<Track>()
        val base = MediaStore.Audio.Media.EXTERNAL_CONTENT_URI
        getApplication<Application>().contentResolver.query(base,
            arrayOf(MediaStore.Audio.Media._ID, MediaStore.Audio.Media.TITLE, MediaStore.Audio.Media.ARTIST),
            "${MediaStore.Audio.Media.IS_MUSIC}!=0", null, "${MediaStore.Audio.Media.TITLE} ASC")?.use { c ->
            while (c.moveToNext()) {
                val id = c.getLong(0)
                out += Track("l$id", c.getString(1) ?: "؟", c.getString(2) ?: "ناشناس", null, ContentUris.withAppendedId(base, id).toString())
            }
        }
        withContext(Dispatchers.Main) { local = out }
    }

    fun search(q: String) = viewModelScope.launch {
        if (q.isBlank()) { results = emptyList(); return@launch }
        busy = true
        results = withContext(Dispatchers.IO) {
            runCatching {
                listOf("music" to false, "musicVideo" to true).flatMap { (media, v) ->
                    val j = JSONObject(URL("https://itunes.apple.com/search?limit=15&media=$media&term=${enc(q)}").readText())
                    val a = j.getJSONArray("results")
                    (0 until a.length()).mapNotNull {
                        val o = a.getJSONObject(it)
                        val u = o.optString("previewUrl")
                        if (u.isEmpty()) null else Track(o.optLong("trackId").toString(), o.optString("trackName"), o.optString("artistName"),
                            o.optString("artworkUrl100").ifEmpty { null }, u, v)
                    }
                }
            }.getOrDefault(emptyList())
        }
        busy = false
    }

    fun play(t: Track) {
        val f = file(t)
        cur = t; lyrics = null
        p.setMediaItem(MediaItem.fromUri(if (f.exists()) Uri.fromFile(f) else Uri.parse(t.url)))
        p.prepare(); p.play()
    }

    fun toggleFav(t: Track) {
        fav = if (fav.any { it.id == t.id }) fav.filter { it.id != t.id } else fav + t
        save("fav", fav)
    }

    fun download(t: Track) = viewModelScope.launch(Dispatchers.IO) {
        runCatching { URL(t.url).openStream().use { i -> file(t).outputStream().use { o -> i.copyTo(o) } } }.onSuccess {
            withContext(Dispatchers.Main) { off = (off + t).distinctBy { it.id }; save("off", off) }
        }
    }

    fun loadLyrics() {
        val t = cur ?: return
        lyrics = "…"
        viewModelScope.launch {
            val s = withContext(Dispatchers.IO) {
                runCatching { JSONObject(URL("https://lrclib.net/api/get?artist_name=${enc(t.artist)}&track_name=${enc(t.title)}").readText()).optString("plainLyrics") }.getOrNull()
            }
            lyrics = if (s.isNullOrEmpty()) "متن این آهنگ پیدا نشد" else s
        }
    }

    fun equalizer(): Equalizer? {
        if (eq == null) eq = runCatching { Equalizer(0, p.audioSessionId).apply { enabled = true } }.getOrNull()
        return eq
    }

    override fun onCleared() { eq?.release(); p.release() }
}

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl) {
                MaterialTheme(colorScheme = darkColorScheme(primary = G, background = BG, surface = BG, onBackground = Color.White, onSurface = Color.White)) { App() }
            }
        }
    }
}

@Composable fun App(vm: VM = viewModel()) {
    var tab by remember { mutableStateOf(0) }
    var q by remember { mutableStateOf("") }
    var full by remember { mutableStateOf(false) }
    val perm = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { if (it) vm.scanLocal() }
    LaunchedEffect(Unit) {
        perm.launch(if (Build.VERSION.SDK_INT >= 33) Manifest.permission.READ_MEDIA_AUDIO else Manifest.permission.READ_EXTERNAL_STORAGE)
    }
    Scaffold(containerColor = BG, bottomBar = {
        Column {
            if (vm.cur != null) Mini(vm) { full = true }
            NavigationBar(containerColor = Color(0xFF0A0A0A)) {
                listOf("خانه" to Icons.Default.Home, "جست‌وجو" to Icons.Default.Search, "کتابخانه" to Icons.Default.LibraryMusic)
                    .forEachIndexed { i, (n, ic) ->
                        NavigationBarItem(selected = tab == i, onClick = { tab = i }, icon = { Icon(ic, n) }, label = { Text(n) })
                    }
            }
        }
    }) { pad ->
        Box(Modifier.padding(pad)) {
            when (tab) { 0 -> Home(vm); 1 -> SearchTab(vm, q) { q = it; vm.search(it) }; else -> Library(vm) }
        }
    }
    if (full) NowPlaying(vm) { full = false }
}

@Composable fun Art(url: String?, mod: Modifier) {
    Box(mod.clip(RoundedCornerShape(6.dp)).background(Color(0xFF333333))) {
        if (url != null) AsyncImage(url, null, Modifier.fillMaxSize(), contentScale = ContentScale.Crop)
        else Icon(Icons.Default.LibraryMusic, null, Modifier.align(Alignment.Center), tint = Color.Gray)
    }
}

@Composable fun Head(s: String) = Text(s, Modifier.padding(16.dp), fontWeight = FontWeight.Bold, style = MaterialTheme.typography.titleMedium)

@Composable fun TrackRow(t: Track, vm: VM) {
    val f = vm.fav.any { it.id == t.id }
    Row(Modifier.fillMaxWidth().clickable { vm.play(t) }.padding(horizontal = 16.dp, vertical = 8.dp), verticalAlignment = Alignment.CenterVertically) {
        Art(t.art, Modifier.size(52.dp))
        Column(Modifier.weight(1f).padding(horizontal = 12.dp)) {
            Text(t.title, maxLines = 1, color = if (vm.cur?.id == t.id) G else Color.White)
            Text(t.artist + if (t.video) " • ویدیو" else "", maxLines = 1, color = Color.Gray, style = MaterialTheme.typography.bodySmall)
        }
        IconButton({ vm.toggleFav(t) }) { Icon(if (f) Icons.Default.Favorite else Icons.Default.FavoriteBorder, null, tint = if (f) G else Color.Gray) }
        if (t.url.startsWith("http")) IconButton({ vm.download(t) }) {
            Icon(if (vm.off.any { it.id == t.id }) Icons.Default.DownloadDone else Icons.Default.Download, null, tint = Color.Gray)
        }
    }
}

@Composable fun Home(vm: VM) {
    LazyVerticalGrid(GridCells.Adaptive(150.dp), contentPadding = PaddingValues(16.dp),
        horizontalArrangement = Arrangement.spacedBy(12.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        item(span = { GridItemSpan(maxLineSpan) }) {
            Column {
                Text("سلام 👋", style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Bold)
                Text(if (vm.local.isEmpty()) "برای دیدن موسیقی‌های دستگاه مجوز بدهید، یا از جست‌وجوی آنلاین استفاده کنید." else "موسیقی‌های شما", color = Color.Gray)
            }
        }
        items(vm.local) { t ->
            Column(Modifier.clickable { vm.play(t) }) {
                Art(t.art, Modifier.fillMaxWidth().aspectRatio(1f))
                Text(t.title, maxLines = 1, modifier = Modifier.padding(top = 6.dp))
                Text(t.artist, maxLines = 1, color = Color.Gray, style = MaterialTheme.typography.bodySmall)
            }
        }
    }
}

@Composable fun SearchTab(vm: VM, q: String, onQ: (String) -> Unit) {
    val loc = if (q.isBlank()) emptyList() else vm.local.filter { it.title.contains(q, true) || it.artist.contains(q, true) }
    Column {
        OutlinedTextField(q, onQ, Modifier.fillMaxWidth().padding(16.dp), placeholder = { Text("آهنگ، هنرمند یا ویدیو…") },
            singleLine = true, shape = RoundedCornerShape(50), leadingIcon = { Icon(Icons.Default.Search, null) })
        if (vm.busy) LinearProgressIndicator(Modifier.fillMaxWidth())
        LazyColumn {
            if (loc.isNotEmpty()) item { Head("روی دستگاه") }
            items(loc) { TrackRow(it, vm) }
            if (vm.results.isNotEmpty()) item { Head("آنلاین (پیش‌نمایش ۳۰ ثانیه‌ای)") }
            items(vm.results) { TrackRow(it, vm) }
        }
    }
}

@Composable fun Library(vm: VM) {
    LazyColumn {
        item { Head("علاقه‌مندی‌ها") }
        items(vm.fav) { TrackRow(it, vm) }
        item { Head("آفلاین") }
        items(vm.off) { TrackRow(it, vm) }
    }
}

@Composable fun Mini(vm: VM, open: () -> Unit) {
    val t = vm.cur ?: return
    Row(Modifier.fillMaxWidth().padding(horizontal = 8.dp).clip(RoundedCornerShape(10.dp)).background(Color(0xFF2A2A2A)).clickable { open() }.padding(8.dp),
        verticalAlignment = Alignment.CenterVertically) {
        Art(t.art, Modifier.size(44.dp))
        Column(Modifier.weight(1f).padding(horizontal = 10.dp)) {
            Text(t.title, maxLines = 1)
            Text(t.artist, maxLines = 1, color = Color.Gray, style = MaterialTheme.typography.bodySmall)
        }
        IconButton({ if (vm.playing) vm.p.pause() else vm.p.play() }) { Icon(if (vm.playing) Icons.Default.Pause else Icons.Default.PlayArrow, null) }
    }
}

@Composable fun NowPlaying(vm: VM, close: () -> Unit) {
    val t = vm.cur ?: return
    var eqOpen by remember { mutableStateOf(false) }
    var pos by remember { mutableStateOf(0f) }
    LaunchedEffect(Unit) {
        while (true) { val d = vm.p.duration; pos = if (d > 0) vm.p.currentPosition.toFloat() / d else 0f; delay(500) }
    }
    Dialog(close, DialogProperties(usePlatformDefaultWidth = false)) {
        Surface(Modifier.fillMaxSize(), color = Color(0xFF181818)) {
            Column(Modifier.padding(20.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                IconButton(close, Modifier.align(Alignment.Start)) { Icon(Icons.Default.Close, null) }
                if (t.video) AndroidView({ PlayerView(it).apply { player = vm.p; useController = false } }, Modifier.fillMaxWidth().aspectRatio(16f / 9f))
                else Art(t.art, Modifier.fillMaxWidth(0.8f).aspectRatio(1f))
                Text(t.title, Modifier.padding(top = 16.dp), style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold, maxLines = 2)
                Text(t.artist, color = Color.Gray)
                Slider(pos, { if (vm.p.duration > 0) vm.p.seekTo((it * vm.p.duration).toLong()) })
                FilledIconButton({ if (vm.playing) vm.p.pause() else vm.p.play() }, Modifier.size(64.dp),
                    colors = IconButtonDefaults.filledIconButtonColors(containerColor = G)) {
                    Icon(if (vm.playing) Icons.Default.Pause else Icons.Default.PlayArrow, null, Modifier.size(36.dp), tint = Color.Black)
                }
                Row { TextButton({ vm.loadLyrics() }) { Text("متن آهنگ") }; TextButton({ eqOpen = true }) { Text("اکولایزر") } }
                Box(Modifier.weight(1f).verticalScroll(rememberScrollState())) { Text(vm.lyrics ?: "") }
            }
        }
    }
    if (eqOpen) {
        val e = vm.equalizer()
        AlertDialog(onDismissRequest = { eqOpen = false }, confirmButton = { TextButton({ eqOpen = false }) { Text("بستن") } },
            title = { Text("اکولایزر") }, text = {
                if (e == null) Text("اکولایزر روی این دستگاه در دسترس نیست") else Column {
                    val r = e.bandLevelRange
                    for (b in 0 until e.numberOfBands) {
                        val bi = b.toShort()
                        var lv by remember { mutableStateOf(e.getBandLevel(bi).toFloat()) }
                        Text("${e.getCenterFreq(bi) / 1000} Hz")
                        Slider(lv, { lv = it; e.setBandLevel(bi, it.toInt().toShort()) }, valueRange = r[0].toFloat()..r[1].toFloat())
                    }
                }
            })
    }
}
