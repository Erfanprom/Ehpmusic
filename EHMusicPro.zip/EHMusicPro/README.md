# EH Music Pro
Kotlin + Jetpack Compose + Media3. رابط فارسی (RTL)، تم تیره سبک Spotify.

## گرفتن APK
1. Android Studio: پوشه را باز کنید → Build ▸ Build APK(s)
2. یا پروژه را در GitHub آپلود کنید → تب Actions ▸ Build APK ▸ Artifacts (فایل debug APK)
برای انتشار واقعی باید APK را امضا (release signing) کنید.
